SMODS.Rarity {
    key = "tate",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.1,
    badge_colour = HEX('e0826c'),
    loc_txt = {
        name = "Tate"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "upgraded_tate",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.015,
    badge_colour = HEX('e6dc61'),
    loc_txt = {
        name = "Upgraded Tate"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "fish_common",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Fish (common)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "fish_common_copy",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('6b8b6a'),
    loc_txt = {
        name = "Fish (uncommon)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "fish_uncommon_copy",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('8b756a'),
    loc_txt = {
        name = "Fish (rare)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "fish_rare_copy",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('8b8b6a'),
    loc_txt = {
        name = "Fish (legendary)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}