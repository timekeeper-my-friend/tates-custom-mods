
SMODS.Edition {
    key = 'evilpolychrome',
    shader = 'polychrome',
    prefix_config = {
        -- This allows using the vanilla shader
        -- Not needed when using your own
        shader = false
    },
    config = {
        extra = {
            mult0 = 5,
            mult = -2
        }
    },
    in_shop = true,
    weight = 0.25,
    extra_cost = 1,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'EVIL Polychrome',
        label = 'EVIL Polychrome',
        text = {
            [1] = 'It\'s polychrome, but {C:hearts}EVIL{}. {C:mult}+5 Mult{}.',
            [2] = 'On the final hand of the round, {C:mult}-2 Mult{}.'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) and to_big(G.GAME.current_round.hands_left) > to_big(1) then
            return {
                mult = 5
            }
        end
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) and to_big(G.GAME.current_round.hands_left) == to_big(1) then
            return {
                mult = -2
            }
        end
    end
}