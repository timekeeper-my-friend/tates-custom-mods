
SMODS.Back {
    key = 'funhouse_mirror_deck',
    pos = { x = 0, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Funhouse Mirror Deck',
        text = {
            [1] = 'At the end of the shop, a',
            [2] = 'random Negative Perishable {C:common}Common{} Joker will be created, assuming there is room.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.ending_shop then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'Joker', rarity = 'Common' })
                    if new_joker then
                        new_joker:set_edition("e_negative", true)
                        new_joker:add_sticker('perishable', true)
                    end
                    return true
                end
            }))
        end
    end,
    
}