SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/dysonsphere.lua"))()
    assert(SMODS.load_file("jokers/upgradeddysonsphere.lua"))()
    assert(SMODS.load_file("jokers/moneyhungry.lua"))()
    assert(SMODS.load_file("jokers/upgradedmoneyhungry.lua"))()
    assert(SMODS.load_file("jokers/digitaljoker.lua"))()
    assert(SMODS.load_file("jokers/upgradeddigitaljoker.lua"))()
    assert(SMODS.load_file("jokers/poorlydrawnjoker.lua"))()
    assert(SMODS.load_file("jokers/worsedrawnjoker.lua"))()
    assert(SMODS.load_file("jokers/wahoo.lua"))()
    assert(SMODS.load_file("jokers/minnow.lua"))()
    assert(SMODS.load_file("jokers/tang.lua"))()
    assert(SMODS.load_file("jokers/mullet.lua"))()
    assert(SMODS.load_file("jokers/trout.lua"))()
    assert(SMODS.load_file("jokers/bass.lua"))()
end
-- load the editions
if true then
    assert(SMODS.load_file("editions/evilpolychrome.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/funhouse_mirror_deck.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
--load sounds
assert(SMODS.load_file("sounds.lua"))()
SMODS.ObjectType({
    key = "tatescus_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "tatescus_tatescus_jokers",
    cards = {
        ["j_tatescus_dysonsphere"] = true,
        ["j_tatescus_upgradeddysonsphere"] = true,
        ["j_tatescus_moneyhungry"] = true,
        ["j_tatescus_upgradedmoneyhungry"] = true,
        ["j_tatescus_digitaljoker"] = true,
        ["j_tatescus_upgradeddigitaljoker"] = true,
        ["j_tatescus_poorlydrawnjoker"] = true,
        ["j_tatescus_worsedrawnjoker"] = true
    },
})

SMODS.ObjectType({
    key = "tatescus_tatescus_fih",
    cards = {
        ["j_tatescus_wahoo"] = true,
        ["j_tatescus_minnow"] = true,
        ["j_tatescus_tang"] = true,
        ["j_tatescus_mullet"] = true,
        ["j_tatescus_trout"] = true,
        ["j_tatescus_bass"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end