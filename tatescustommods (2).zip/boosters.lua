
SMODS.Booster {
    key = 'fishingpack',
    loc_txt = {
        name = "Fishing Pack",
        text = {
            [1] = 'Open the pack for a {C:blue}fish{}.'
        },
        group_name = "fish"
    },
    config = { extra = 1, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "tatescus_tatescus_fih",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "tatescus_fishingpack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("467ca1"))
        ease_background_colour({ new_colour = HEX('467ca1'), special_colour = HEX("2aeac0"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    