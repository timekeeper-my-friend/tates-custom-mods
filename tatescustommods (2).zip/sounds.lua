SMODS.Sound{
    key="fihsound",
    path="fihsound.ogg",
    pitch=0.7,
    volume=0.6,
}