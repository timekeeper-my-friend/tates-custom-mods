
SMODS.Joker{ --Upgraded Dyson Sphere
    key = "upgradeddysonsphere",
    config = {
        extra = {
            chipsAdded = 0,
            odds = 4,
            odds2 = 4,
            odds3 = 4,
            odds4 = 4,
            odds5 = 4,
            odds6 = 4,
            odds7 = 4,
            odds8 = 4,
            odds9 = 4,
            odds10 = 4,
            odds11 = 4,
            odds12 = 4,
            odds13 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Upgraded Dyson Sphere',
        ['text'] = {
            [1] = 'When a card is scored, {C:green}1 in 4{} chance to',
            [2] = 'add {C:gold}the rank{} (rounded up) to Chips:',
            [3] = 'Currently {C:chips} #1# {}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "tatescus_upgraded_tate",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["tatescus_tatescus_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_tatescus_upgradeddysonsphere')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_tatescus_upgradeddysonsphere')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_tatescus_upgradeddysonsphere')
        local new_numerator5, new_denominator5 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds5, 'j_tatescus_upgradeddysonsphere')
        local new_numerator6, new_denominator6 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds6, 'j_tatescus_upgradeddysonsphere')
        local new_numerator7, new_denominator7 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds7, 'j_tatescus_upgradeddysonsphere')
        local new_numerator8, new_denominator8 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds8, 'j_tatescus_upgradeddysonsphere')
        local new_numerator9, new_denominator9 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds9, 'j_tatescus_upgradeddysonsphere')
        local new_numerator10, new_denominator10 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds10, 'j_tatescus_upgradeddysonsphere')
        local new_numerator11, new_denominator11 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds11, 'j_tatescus_upgradeddysonsphere')
        local new_numerator12, new_denominator12 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds12, 'j_tatescus_upgradeddysonsphere')
        local new_numerator13, new_denominator13 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds13, 'j_tatescus_upgradeddysonsphere')
        return {vars = {card.ability.extra.chipsAdded, new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4, new_numerator5, new_denominator5, new_numerator6, new_denominator6, new_numerator7, new_denominator7, new_numerator8, new_denominator8, new_numerator9, new_denominator9, new_numerator10, new_denominator10, new_numerator11, new_denominator11, new_numerator12, new_denominator12, new_numerator13, new_denominator13}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 2 then
                if SMODS.pseudorandom_probability(card, 'group_0_4a3095ab', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 2
                    
                end
            elseif context.other_card:get_id() == 3 then
                if SMODS.pseudorandom_probability(card, 'group_0_0a8283e5', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 3
                    
                end
            elseif context.other_card:get_id() == 4 then
                if SMODS.pseudorandom_probability(card, 'group_0_a9dd27b2', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 4
                    
                end
            elseif context.other_card:get_id() == 5 then
                if SMODS.pseudorandom_probability(card, 'group_0_029c1dc9', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 5
                    
                end
            elseif context.other_card:get_id() == 6 then
                if SMODS.pseudorandom_probability(card, 'group_0_35e704b4', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 6
                    
                end
            elseif context.other_card:get_id() == 7 then
                if SMODS.pseudorandom_probability(card, 'group_0_8e5e6134', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 7
                    
                end
            elseif context.other_card:get_id() == 8 then
                if SMODS.pseudorandom_probability(card, 'group_0_0d6771bf', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 8
                    
                end
            elseif context.other_card:get_id() == 9 then
                if SMODS.pseudorandom_probability(card, 'group_0_2272df61', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 9
                    
                end
            elseif context.other_card:get_id() == 10 then
                if SMODS.pseudorandom_probability(card, 'group_0_b0969257', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 10
                    
                end
            elseif context.other_card:get_id() == 11 then
                if SMODS.pseudorandom_probability(card, 'group_0_9cc98c00', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 11
                    
                end
            elseif context.other_card:get_id() == 12 then
                if SMODS.pseudorandom_probability(card, 'group_0_615a6350', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 12
                    
                end
            elseif context.other_card:get_id() == 13 then
                if SMODS.pseudorandom_probability(card, 'group_0_360480b8', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 13
                    
                end
            elseif context.other_card:get_id() == 14 then
                if SMODS.pseudorandom_probability(card, 'group_0_79d5b5a9', 1, card.ability.extra.odds, 'j_tatescus_upgradeddysonsphere', false) then
                    card.ability.extra.chipsAdded = (card.ability.extra.chipsAdded) + 14
                    
                end
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.chipsAdded
            }
        end
    end
}