
SMODS.Joker{ --Worse Drawn Joker
    key = "worsedrawnjoker",
    config = {
        extra = {
            mult0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Worse Drawn Joker',
        ['text'] = {
            [1] = '{C:mult}+1{} Mult. Obtainable via {C:uncommon}Poorly Drawn Joker{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = "tatescus_tate",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["tatescus_tatescus_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 1
            }
        end
    end
}