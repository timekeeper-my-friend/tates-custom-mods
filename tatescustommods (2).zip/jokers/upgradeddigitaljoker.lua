
SMODS.Joker{ --Upgraded Digital Joker
    key = "upgradeddigitaljoker",
    config = {
        extra = {
            OS = -1,
            addMult = 0,
            addChips = 0,
            multipliedDeck = 0,
            freejokerslots = 1,
            cumulativechips = 1,
            xmult0 = 3,
            odds = 30,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Upgraded Digital Joker',
        ['text'] = {
            [1] = 'This joker\'s ability will vary depending on your computer\'s OS.',
            [2] = 'Windows - {C:mult}x3{} Mult, {C:green}1 in 30 chance{} to self-destruct',
            [3] = 'Mac - {C:blue}+200{} Chips and {C:mult}+4{} Mult for each empty joker slot',
            [4] = 'Linux - On hand played, {C:mult}+6{} Mult for every {C:chips}50{} Chips scored in the hand.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "tatescus_upgraded_tate",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["tatescus_tatescus_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_tatescus_upgradeddigitaljoker') 
    return {vars = {card.ability.extra.OS, card.ability.extra.addMult, card.ability.extra.addChips, card.ability.extra.multipliedDeck, card.ability.extra.var1, card.ability.extra.freejokerslots + (((G.jokers and G.jokers.config.card_limit or 0) - #(G.jokers and (G.jokers and G.jokers.cards or {}) or {}))) * 200, card.ability.extra.cumulativechips + ((function() local chips_sum = 0; for _, playing_card in pairs(context.scoring_hand or {}) do chips_sum = chips_sum + playing_card.base.nominal end; return chips_sum end)) * 0.02, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.ante_change  then
            if love.system.getOS() == "Windows" then
                return {
                    func = function()
                        card.ability.extra.OS = 1
                        return true
                    end
                }
            elseif love.system.getOS() == "OS X" then
                return {
                    func = function()
                        card.ability.extra.OS = 2
                        return true
                    end
                }
            elseif love.system.getOS() == "Linux" then
                return {
                    func = function()
                        card.ability.extra.OS = 3
                        return true
                    end
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if to_big((card.ability.extra.var1 or 0)) == to_big(2) then
                card.ability.extra.multipliedDeck = (card.ability.extra.multipliedDeck) * card.ability.extra.freejokerslots + (((G.jokers and G.jokers.config.card_limit or 0) - #(G.jokers and G.jokers.cards or {}))) * 200
                return {
                    chips = card.ability.extra.multipliedDeck,
                    extra = {
                        mult = card.ability.extra.freejokerslots + (((G.jokers and G.jokers.config.card_limit or 0) - #(G.jokers and G.jokers.cards or {}))) * 4
                    }
                }
            elseif to_big((card.ability.extra.OS or 0)) == to_big(1) then
                return {
                    Xmult = 3
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_e4c34792', 1, card.ability.extra.odds, 'j_tatescus_upgradeddigitaljoker', false) then
                            local target_joker = card
                            
                            if target_joker then
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        target_joker:explode({G.C.RED}, nil, 1.6)
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                            end
                            SMODS.calculate_effect({func = function()
                                local target_joker = G.P_CENTERS["j_tatescus_digitaljoker"]
                                if target_joker then
                                    unlock_card(target_joker)
                                    discover_card(target_joker)
                                    
                                else
                                    error("JOKERFORGE: Invalid joker key in Unlock Joker Effect. Did you forget the modprefix or misspelled the key?")
                                end
                                return true
                            end}, card)
                        end
                        return true
                    end
                }
            elseif to_big((card.ability.extra.OS or 0)) == to_big(3) then
                return {
                mult = card.ability.extra.cumulativechips + ((function() local chips_sum = 0; for _, playing_card in pairs(context.scoring_hand or {}) do chips_sum = chips_sum + playing_card.base.nominal end; return chips_sum end)) * 0.02
                }
            end
        end
    end
}